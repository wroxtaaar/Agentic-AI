# VPS deployment

## 1. Create the GitHub repository

Create an empty private repository named `oracle-vps-agent`, then from this directory:

```bash
git remote add origin https://github.com/YOUR_USER/oracle-vps-agent.git
git push -u origin main
```

## 2. Install on Oracle VPS

```bash
cd ~
git clone https://github.com/YOUR_USER/oracle-vps-agent.git
cd oracle-vps-agent
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
nano .env
```

Set the generated value as `AGENT_API_TOKEN`, your OpenRouter key as `OPENROUTER_API_KEY`, and configure `AGENT_WORKSPACE_ROOTS` to the directories containing your projects.

## 3. Start

```bash
source .venv/bin/activate
python -m uvicorn app:app --host 127.0.0.1 --port 8787
```

Check:

```bash
curl http://127.0.0.1:8787/health
```

## 4. Keep it running

Copy `systemd.service.example` to `/etc/systemd/system/oracle-vps-agent.service`, adjust the home path if necessary, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now oracle-vps-agent
sudo systemctl status oracle-vps-agent
```

## 5. Private access

Prefer exposing the service through Tailscale rather than opening port 8787 publicly. The app itself listens on localhost in the systemd example.
