# Oracle VPS Agent

A self-hosted multi-agent engineering system for managing software projects and services on an Oracle VPS.

## Agent team

- **Orchestrator** — routes each request to the right specialist and coordinates multi-step work.
- **Project Agent** — discovers repositories, understands project structure, and keeps project context.
- **Coding Agent** — diagnoses source problems and creates exact, approval-gated patches.
- **DevOps Agent** — investigates Docker containers, services, resources, and runtime failures.
- **Git Agent** — reads branches, status, history and diffs.
- **Debugger Agent** — combines logs, source and runtime evidence to find root causes.
- **Security Agent** — checks proposed operations for secret exposure and dangerous scope.
- **Verification Agent** — runs approved checks after changes.
- **Memory Agent** — stores durable project architecture and decisions without secrets.

The LLM reasons; the local execution layer enforces permissions.

## Safety model

Read operations are available automatically. Mutations go through an approval queue. Every source patch records exact `old_text`, `new_text`, target path, and a SHA-256 snapshot. Applying a patch requires the snapshot to still match and creates a backup first.

The generic shell is allowlisted and read-only. Docker/Git have dedicated tools. Secrets and credential files are blocked/redacted.

## VPS setup

```bash
git clone https://github.com/YOUR_USER/oracle-vps-agent.git
cd oracle-vps-agent
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python -m uvicorn app:app --host 0.0.0.0 --port 8787
```

Recommended `.env` values:

```env
AI_PROVIDER=openrouter
OPENROUTER_API_KEY=...
OPENROUTER_MODEL=openrouter/free
AGENT_API_TOKEN=generate-a-long-random-token
AGENT_WORKSPACE_ROOTS=/home/ubuntu
```

For production, put the API behind Tailscale, a reverse proxy, or another private network. Do not expose the raw control API to the public internet.

## API

- `GET /health`
- `GET /api/status` — VPS, repositories and containers
- `POST /api/chat` — send a task to the orchestrator
- `GET /api/approvals` — pending actions
- `POST /api/approvals/{id}/approve`
- `POST /api/approvals/{id}/reject`
- `POST /api/approvals/{id}/execute`

## Example tasks

- `Check all my projects and tell me which ones look unhealthy.`
- `Investigate why torrent-studio is failing.`
- `Fix the crash in FinanceSMSTracker and prepare a patch.`
- `Check the Docker containers and find anything using too much memory.`
- `Explain what changed in the last deployment.`

The agent should investigate first, explain evidence, then ask for approval before changing anything.
