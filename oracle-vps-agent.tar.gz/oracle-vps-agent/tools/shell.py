import subprocess
ALLOWED={'pwd','whoami','uname','df','free','uptime','hostname','ls','find'}
FORBIDDEN={'-exec','-execdir','-delete','-ok','-okdir','-fls','-fprint','-fprintf'}
def run(command):
    command=command.strip()
    if not command:return {'success':False,'error':'Empty command'}
    if any(x in command for x in (';','|','>','<','`','$(','&&','||','\n','\r')): return {'success':False,'error':'Shell operators are not allowed'}
    parts=command.split()
    if parts[0] not in ALLOWED:return {'success':False,'error':f'Command not allowlisted: {parts[0]}'}
    if set(x.lower() for x in parts[1:]) & FORBIDDEN:return {'success':False,'error':'Unsafe find option'}
    try:
        r=subprocess.run(parts,capture_output=True,text=True,timeout=15)
        return {'success':r.returncode==0,'stdout':r.stdout[-10000:],'stderr':r.stderr[-5000:],'return_code':r.returncode}
    except Exception as e:return {'success':False,'error':str(e)}
