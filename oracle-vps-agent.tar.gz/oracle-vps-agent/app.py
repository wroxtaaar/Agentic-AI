import os
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from core.orchestrator import Orchestrator
from core.approvals import list_pending,get,set_status
from tools.patches import approve,apply
from tools.docker import restart
from tools.system import info
from tools.projects import discover
from tools.docker import list_containers
load_dotenv()
app=FastAPI(title='Oracle VPS Agent',version='1.0.0')

def auth(authorization: str|None=Header(default=None)):
    token=os.getenv('AGENT_API_TOKEN')
    if not token:raise HTTPException(503,'AGENT_API_TOKEN is not configured')
    if authorization!=f'Bearer {token}':raise HTTPException(401,'Unauthorized')

class Chat(BaseModel):
    message:str=Field(min_length=1,max_length=12000)
    history:list[dict]=Field(default_factory=list,max_length=20)

@app.get('/health')
def health():return {'status':'ok','service':'oracle-vps-agent','version':app.version}
@app.get('/api/status')
def status(authorization:str|None=Header(default=None)):
    auth(authorization);return {'system':info(),'projects':discover(),'containers':list_containers()}
@app.post('/api/chat')
def chat(req:Chat,authorization:str|None=Header(default=None)):
    auth(authorization);return Orchestrator().run(req.message,req.history)
@app.get('/api/approvals')
def approvals(authorization:str|None=Header(default=None)):
    auth(authorization);return {'approvals':list_pending()}
@app.get('/api/approvals/{aid}')
def approval(aid:str,authorization:str|None=Header(default=None)):
    auth(authorization); item=get(aid)
    if not item:raise HTTPException(404,'Approval not found')
    return item
@app.post('/api/approvals/{aid}/approve')
def approval_approve(aid:str,authorization:str|None=Header(default=None)):
    auth(authorization); item=get(aid)
    if not item:raise HTTPException(404,'Approval not found')
    return set_status(aid,'approved')
@app.post('/api/approvals/{aid}/reject')
def approval_reject(aid:str,authorization:str|None=Header(default=None)):
    auth(authorization); return set_status(aid,'rejected')
@app.post('/api/proposals/{pid}/approve')
def proposal_approve(pid:str,authorization:str|None=Header(default=None)):
    auth(authorization); return approve(pid)
@app.post('/api/proposals/{pid}/apply')
def proposal_apply(pid:str,authorization:str|None=Header(default=None)):
    auth(authorization); return apply(pid)
@app.post('/api/actions/restart-container')
def restart_container(container:str,authorization:str|None=Header(default=None)):
    auth(authorization); return restart(container)
@app.get('/',include_in_schema=False)
def index():return FileResponse(Path(__file__).parent/'web'/'index.html')
